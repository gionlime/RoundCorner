package make.more.r2d2.round_corner.shadow;

/**
 * Created by HeZX on 2019-07-15.
 */
public interface ShadowAble {
    ShadowHelper getShadowHelper();
}
