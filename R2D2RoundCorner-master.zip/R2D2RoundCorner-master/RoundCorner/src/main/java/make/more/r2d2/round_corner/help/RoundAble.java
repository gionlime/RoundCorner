package make.more.r2d2.round_corner.help;

/**
 * Created by HeZX on 2019-07-09.
 */
public interface RoundAble {
    RoundHelper getRoundHelper();
}
